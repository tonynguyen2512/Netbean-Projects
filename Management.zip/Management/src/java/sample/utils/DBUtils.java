/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
<%-- 
    Document   : index
    Created on : Mar 13, 2021, 9:58:50 AM
    Author     : hd
--%>
 */
package sample.utils;

/**
 *
 * @author hd
 */
public class DBUtils {
    
}
